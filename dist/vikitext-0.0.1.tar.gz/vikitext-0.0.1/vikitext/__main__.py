from extract_hyperlinks import get_hyperlinks as get_hl
from article_links import make_urlset as get_urls
from get_text import get_content as get_txt
